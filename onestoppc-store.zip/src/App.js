import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

function HomePage() {
  return (
    <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center">
      <h1 className="text-4xl font-bold mb-6">Welcome to OneStopPC</h1>
      <Link to="/build" className="bg-orange-500 hover:bg-orange-400 px-6 py-3 rounded-xl text-black font-semibold">Build Your PC</Link>
    </div>
  );
}

function BuildPage() {
  return (
    <div className="min-h-screen bg-black text-white p-10">
      <h1 className="text-3xl font-bold mb-4">🧱 Build Tool Coming Soon</h1>
      <p className="text-gray-400">You're on the right track! The build tool will be connected here.</p>
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/build" element={<BuildPage />} />
      </Routes>
    </Router>
  );
}

export default App;